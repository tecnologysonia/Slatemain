---
title: SESApp API Docs

language_tabs: # must be one of https://git.io/vQNgJ


toc_footers:
  - <a href='#'>Sign Up for a Developer Key</a>
  - <a href='https://github.com/slatedocs/slate'>Documentation Powered by Slate</a>

includes:


search: true

code_clipboard: true
---

# Introduction
La API de Openpay está diseña sobre [REST](https://es.wikipedia.org/wiki/Transferencia_de_Estado_Representacional), por lo tanto encontrarás que las URL están orientadas a recursos y se usa códigos de respuesta HTTP para indicar los errores en la API.

Todas las respuestas de la API están en formato [JSON](https://www.json.org/json-en.html), incluyendo errores.

En el caso de usar los clientes existentes del API de Openpay ([Java, Php, C#, Python, Ruby, NodeJS]), las respuestas son específicamente del tipo definido en dichos clientes en sus respectivos lenguajes.

# API Endpoints
>   Recurso disponibles

>a) Por Comercio

```json
/v1/{MERCHANT_ID}/...
/fees
/fees/{FEE_ID}
/charges
/charges/{TRANSACTION_ID}
/payouts
/payouts/{TRANSACTION_ID}
/cards
/cards/{CARD_ID}
/customers
/customers/{CUSTOMER_ID}
/plans
/plans/{PLAN_ID}
​/tokens
/tokens/{TOKEN_ID}
```
>b) Por Cliente

```json
/v1/{MERCHANT_ID}/customers/{CUSTOMER_ID}/...

/cards
/cards/{CARD_ID}
/bankaccounts
/bankaccounts/{BANKACCOUNT_ID}
/charges
/charges/{TRANSACTION_ID}
/payouts
/payouts/{TRANSACTION_ID}
/transfers
/transfers/{TRANSACTION_ID}
/subscriptions
/subscriptions/{SUBSCRIPTION_ID}
```


La API REST de Openpay tiene un ambiente de pruebas (sandbox) y un ambiente de producción. Usa las credenciales que se generaron al momento de tu registro para realizar la integración de tu sistema con Openpay. Una vez que estes listo para pasar a producción y tu solicitud sea aprobada, se generarán nuevas credenciales para acceder al ambiente de producción.

La siguientes URIs forman la base de los endpoints para los ambientes soportados:

    <ul><li><b>Pruebas,</b> URI base:</li></ul>
         <p>`https://sandbox-api.openpay.mx`</p>
       <ul><li><b>Producción,</b> URI base:</li></ul>
         <p>`https://api.openpay.mx`</p>


Un endpoint completo esta formado por la URI base del ambiente, el identificador del comercio y el recurso.

Por ejemplo, si queremos crear un nuevo cliente, el endpoint sería:


`POST https://sandbox-api.openpay.mx/v1/mzdtln0bmtms6o3kck8f/customers`

Para crear una petición completa es necesaria envíar las cabeceras HTTP correctas y la información en formato JSON.
Todos los ejemplos de está documentación están apuntados al ambiente de pruebas.
# Autenticación
> Ejemplo de autenticación

```json

var Openpay = require('openpay');

var openpay = new Openpay('moiep6umtcnanql3jrxp','sk_3433941e467c4875b178ce26348b0fac');
openpay.setProductionReady(true);


```

Para realizar peticiones a la API de Openpay, es necesario enviar la llave de API (API Key) en todas tus llamadas a nuestros servidores. ​La llave la puedes obtener desde el [dashboard](https://sandbox-dashboard.openpay.mx/login).

Existen 2 tipos de llaves de API:

<ul><li><b>Privada.- </b>Para llamadas entre servidores y con acceso total a todas las operaciones de la API (nunca debe ser compartida)</li></ul>
<aside class="warning">
Manten esta <code> llave</code> segura y nunca la compartas con nadie.
</aside>

<ul><li><b>Pública.-</b> Sólo se debe utilizar en llamadas desde JavaScript. Esta llave sólo tiene permitido realizar crear tarjetas o crear tokens</li></ul>

<aside class="notice">Para hacer llamadas con tu llave pública utiliza la librería [Openpay.js](#)</aside>

Para la autenticación al API debes usar autenticación de acceso básica, donde la llave de API es el nombre de usuario. La contraseña no es requerida y debe dejarse en blanco por fines de simplicidad.
<aside class="notice">Por razones de seguridad todas las peticiones deben ser vía **HTTPS**.</aside>


# Metodos

## Metodo para insertar usuarios
Este endpoint  recupera todos los usuarios.

> jSON para el metodo insertusuario:

```json

  {
    "nickname":"juan",
    "nombre":"jorge luiyi",
    "escuela":"Agustin Arrieta",
    "id_municipio":1,
    "fecha":"1994/04/19",
    "contrasena": "12345",
    "sexo":"masculino",
    "personaje_imagen": "",
    "partes_personaje": "",
    "correo":"jorge@gmail.com"
}

```
> El comando anterior devuelve JSON estructurado así:

```json
{
  "idusuario":"4",
  "nombreUsuario":"juan",
  "nombre":"jorge luiyi",
  "escuela":"Agustin Arrieta",
  "id_municipio":"1",
  "fechaNacimiento":"1994-04-19",
  "contrasena":"827ccb0eea8a706c4c34a16891f84e7b",
  "sexo":"masculino",
  "vidas":"3",
  "monedas":"0",
  "trofeos":"0",
  "numcategoria":"1",
  "respondidas":"",
  "fechaUltimaActualizacion":"2020-09-01 11:21:31",
  "personaje_imagen":"",
  "partes_personaje":"",
  "item_comprados":"",
  "correo":"jorge@gmail.com"
}
```


### HTTP Request

`POST http://localhost/sesa/api/index.php/insertusuario`

###  Parámetros del Metodo Insertusuario

Parametero | Tipo | Descripción
--------- | ------- | -----------
usuario   | varchar | Esta variable guarda el <code><b>nickname </b></code>del usuario.
nombre    | varchar | Esta variable guarda el nombre del usuario.
escuela   | varchar | Esta variable guarda el nombre de la escuela.
id_municipio | int | Esta variable guarda la FK de la tabla municipio.
fecha | date | Esta variable guarda la fecha de nacimiento del usuario.
contrasena| varchar | Esta variable guarda la contraseña del usuario.
sexo | varchar | Esta variable guarda el sexo del usuario.
personaje| varchar | Esta variable guarda el nombre de la imagen.
partes_personaje| varchar | Esta variable guarda el nombre de las partes del personaje.
correo | varchar | Esta variable guarda el correo del usuario.


## Metodo para validar el Nickname

Este endpoint  valida el nickname de los usuarios

> jSON para el metodo validateNickname:

```json

{
  "nombreUsuario":"Jorgito"
}

```
> El comando anterior devuelve JSON estructurado así:

```json
{
  "respuesta":"false",
  "nickname":Jorgito
}
```


### HTTP Request

`POST http://localhost/sesa/api/index.php/validatenickname`

###  Parámetros del Metodo validatenickname

Parametero | Tipo | Descripción
--------- | ------- | -----------
usuario   | varchar | Esta variable guarda el <code><b>nombreUsuario</b></code>del usuario.

<aside class="success">
Recuerda— nombreUsuario es el nombre del campo de la base de datos!
</aside>

## Metodo para validar_correo

Este endpoint  valida el correo de los usuarios

> jSON para el metodo validar_correo:

```json
{
  "correo":"jorge@gmail.com"
}

```
> El comando anterior devuelve JSON estructurado así:

```json
{
  "respuesta":"false",
  "correo":jorge@gmail.com
}
```


### HTTP Request

`POST http://localhost/sesa/api/index.php/validar_correo`

###  Parámetros del Metodo validar_correo

Parametero | Tipo | Descripción
--------- | ------- | -----------
email     | varchar | Esta variable guarda el <code><b>correo</b></code>del usuario.

<aside class="success">
Recuerda— correo es el nombre del campo de la base de datos!
</aside>

## Metodo para login

Este endpoint  valida el nombre del usuario y la contraseña para poder logearse.

> jSON para el metodo login:

```json
{
  "nombreUsuario":"Jorgito",
  "contrasena":"827CCB0EEA8A706C4C34A16891F84E7B"
}

```
> El comando anterior devuelve JSON estructurado así:

```json
{
  "respuesta":"false"
}
```


### HTTP Request

`POST http://localhost/sesa/api/index.php/login`

###  Parámetros del Metodo login

Parametero | Tipo | Descripción
--------- | ------- | -----------
pass      | varchar | Esta variable guarda la <code><b>contrasena</b></code>del usuario.
usuario   | varchar | Esta variable guarda la <code><b>nombreUsuario</b></code>del usuario.

<aside class="success">
Recuerda— pass y usuario son nombres de los campos de la base de datos!
</aside>


----
## Metodo para actualizar UpdateScore

Este endpoint actualiza el score

> jSON para el metodo login:

```json
{
"idusuario":"1",
"vidas":"1",
"score":"46",
"trofeos":"1",
"numcategoria":"2",
"respondidas":"0"
}

```
> El comando anterior devuelve JSON estructurado así:

```json
{
  "idusuario":"1",
  "nombreUsuario":"Jorgito",
  "nombre":"Jorge Luis Avila",
  "escuela":"Agustin Arrieta",
  "id_municipio":"1","fechaNacimiento":"1994-04-19",
  "contrasena":"827ccb0eea8a706c4c34a16891f84e7b",
  "sexo":"masculino",
  "score":"46",
  "vidas":"1",
  "monedas":"0",
  "trofeos":"1",
  "numcategoria":"2",
  "respondidas":"0",
  "fechaUltimaActualizacion":"2020-09-01 18:59:55",
  "personaje_imagen":"",
  "partes_personaje":"",
  "item_comprados":"",
  "correo":"jorge@gmail.com"
}
```


### HTTP Request

`POST http://localhost/sesa/api/index.php/updatescore`
`UPDATE  http://localhost/sesa/api/index.php/updatescore<ID>`

###  Parámetros del Metodo UpdateScore

Parametero | Tipo | Descripción
--------- | ------- | -----------
id| int | Esta variable guarda el <code><b>idusuario</b></code>del usuario.
score| int| Esta variable guarda el <code><b>score o puntaje</b></code>del usuario.
vidas| int | Esta variable guarda el numero de<code><b>vidas</b></code>del usuario.
trofeos| int | Esta variable guarda el numero de <code><b>trofeos</b></code>del usuario.
cateogria| int | Esta variable guarda el numero de  <code><b>categoria</b></code>del usuario.
respondidas | text | Esta variable guarda el numero de <code><b>respondias</b></code>del usuario.     
